NEXUS NOTES — PREMIUM DASHBOARD UPDATE
======================================
This is a local HTML/CSS/JavaScript website. It works with no installation or paid services.

HOW TO USE
1. Extract the ZIP file (right-click ZIP -> Extract All).
2. Open the NexusNotes_Premium folder in VS Code, if you want to edit it.
3. Right-click index.html -> Open with Live Server, OR double-click index.html in File Explorer.
4. Use the new sidebar and dashboard.

IMPORTANT — YOUR EXISTING NOTES
- The original Nexus Notes project saved data in your browser's localStorage.
- These files use the same storage keys: notebooks, goals, tasks, events.
- To keep your EXISTING browser data, BACK UP YOUR OLD PROJECT FOLDER, then copy the new index.html,
  css/style.css and js/*.js INTO YOUR EXISTING PROJECT FOLDER and open the SAME Live Server URL.
- If you open the new project at a different browser origin or file URL, your old notes might not show up.
- There is a new Settings -> Download backup feature. Use it regularly; a new copy/folder does not sync data.
- Deleting browser data or changing browser/origin may remove stored notes. No cloud sync yet.

WHAT'S INCLUDED
- Redesigned high-quality animated homepage, responsive sidebar, quick actions, live stats.
- Animated transitions between pages and smooth card hover effects.
- Existing 450-page notebooks and local saving.
- Task groups with unlimited task pages, editable task page names, checklists and page deletion.
- Goals and motivation based on the closest upcoming goal deadline.
- Full month-view calendar, events, and clickable days.
- Global search (Ctrl+K), note reading with voices provided by your browser.
- Settings: name, light/dark theme, import/export backups.

NOT CONNECTED YET
- Gemini AI, Google Login, cloud sync, PDF AI, optical note scanning, true offline installable PWA.
- The AI and Tools Hub screens are previews, not working integrations.
- Voice options depend on voices installed in your browser/Windows; exact Siri voice is not guaranteed.

SHORTCUTS
Ctrl+K = search; Ctrl+N = create notebook; Ctrl+S = save; Esc = close search.
