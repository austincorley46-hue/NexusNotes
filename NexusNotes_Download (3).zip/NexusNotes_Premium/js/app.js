function renderAll(){renderNotebooks();renderGoals();renderTasks();renderEvents();updateDashboard();renderCalendar();}
function renderNotebooks(){
  const list=el('notebookList');
  list.innerHTML=notebooks.length?notebooks.map((book,i)=>`<div class="notebook-tile"><div class="tile-cover">✦</div><h4>${esc(book.name)}</h4><small>${(book.pages||[]).filter(p=>typeof p==='string'&&p.trim()).length} of 450 pages used</small><div class="tile-actions"><button class="button button-secondary" onclick="openNotebook(${i})">Open</button><button class="button button-danger" onclick="deleteNotebook(${i})">Delete</button></div></div>`).join(''):'<div class="empty-state">No notebooks yet. Create your first one above.</div>';
  el('notebookCount').textContent=`${notebooks.length} notebook${notebooks.length===1?'':'s'}`;
}
function renderGoals(){
  const list=el('goalList');
  list.innerHTML=goals.length?goals.map((g,i)=>{
    const p=clampProgress(g.progress);
    return `<div class="item"><div class="goal-item-header"><strong>${esc(g.title)}</strong><div class="item-actions"><button class="button button-secondary" onclick="updateGoalProgress(${i})">Update progress</button><button class="button button-danger" onclick="deleteGoal(${i})">Delete</button></div></div><div class="goal-metadata"><span>${esc(g.priority||'Medium')} priority</span><span>${validDate(g.date)?esc(g.date):'No deadline'}</span><span>${p}% complete</span></div><div class="progress"><div style="width:${p}%"></div></div></div>`;
  }).join(''):'<div class="empty-state">No goals yet. Add one above and see it on your dashboard.</div>';
}
function renderTasks(){
  el('taskList').innerHTML=tasks.length?tasks.map((t,i)=>`<div class="item"><input class="task-checkbox" aria-label="Mark task complete" type="checkbox" ${t.done?'checked':''} onchange="toggleTask(${i})"><span class="item-main ${t.done?'task-done':''}"><strong>${esc(t.text)}</strong><small>${(t.pages||[]).length} page${(t.pages||[]).length===1?'':'s'}</small></span><span class="item-actions"><button class="button button-secondary" onclick="openTask(${i})">Open pages</button><button class="button button-danger" onclick="deleteTask(${i})">Delete</button></span></div>`).join(''):'<div class="empty-state">No task groups yet. Add one above.</div>';
}
function renderEvents(){
  el('eventList').innerHTML=events.length?[...events].map((e,i)=>({e,i})).sort((a,b)=>String(a.e.date).localeCompare(String(b.e.date))).map(({e,i})=>`<div class="item"><span class="item-main"><strong>${esc(e.name)}</strong><small>${esc(e.date||'No date')}</small></span><button class="button button-danger" onclick="deleteEvent(${i})">Delete</button></div>`).join(''):'<div class="empty-state">No events scheduled. Add an event above.</div>';
}
function updateDashboard(){
  const openTasks=tasks.filter(t=>!t.done).length;
  const activeGoals=goals.filter(g=>clampProgress(g.progress)<100).length;
  const upcoming=events.filter(e=>validDate(e.date)&&e.date>=todayKey());
  el('statNotebooks').textContent=notebooks.length;
  el('statTasks').textContent=openTasks;
  el('statGoals').textContent=activeGoals;
  el('statEvents').textContent=upcoming.length;
  const nearest=closestGoal();
  if(nearest){
    const progress=clampProgress(nearest.progress);
    el('dashboardGoal').innerHTML=`<div class="goal-focus-title">${esc(nearest.title)}</div><div class="goal-tags"><span class="tag">${esc(nearest.priority||'Medium')} priority</span><span class="tag-date">${validDate(nearest.date)?'◎ Due '+esc(nearest.date):'◎ No deadline set'}</span></div><div class="progress"><div style="width:${progress}%"></div></div><div class="progress-row"><span>Keep moving forward</span><strong>${progress}% complete</strong></div><div class="motivation-box">✧ ${esc(motivationFor(nearest))}</div>`;
  }else{
    el('dashboardGoal').innerHTML='<div class="empty-state"><strong>Your next goal starts here.</strong><p>Choose something you want to work toward and watch your progress grow.</p><button onclick="quickCreate(\'goal\')">＋ Create a goal</button></div>';
  }
  const lastThree=notebooks.map((b,i)=>({b,i})).slice(-3).reverse();
  el('dashboardBooks').innerHTML=lastThree.length?lastThree.map(({b,i})=>`<button class="notebook-row" onclick="openNotebook(${i})"><span class="book-thumb">✦</span><span class="book-info"><b>${esc(b.name)}</b><small>${(b.pages||[]).filter(p=>typeof p==='string'&&p.trim()).length} pages written · 450 available</small></span><svg><use href="#ic-chevron"/></svg></button>`).join(''):'<div class="empty-state">Your notebooks will appear here.<p>Start with your first idea.</p><button onclick="quickCreate(\'notebook\')">＋ Create notebook</button></div>';
  const dashboardTasks=tasks.map((t,i)=>({t,i})).filter(o=>!o.t.done).slice(0,5);
  el('dashboardTasks').innerHTML=dashboardTasks.length?dashboardTasks.map(({t,i})=>`<label class="dash-task"><input type="checkbox" onchange="toggleTask(${i})" aria-label="Complete task"><span>${esc(t.text)}</span></label>`).join(''):'<div class="empty-state">Nothing pending. A clear list feels good!</div>';
  const nextEvents=events.map((e,i)=>({e,i})).filter(({e})=>validDate(e.date)&&e.date>=todayKey()).sort((a,b)=>a.e.date.localeCompare(b.e.date)).slice(0,3);
  el('dashboardEvents').innerHTML=nextEvents.length?nextEvents.map(({e})=>{
    const [year,month,day]=e.date.split('-').map(Number);
    const dt=new Date(year,month-1,day);
    const mon=dt.toLocaleDateString(undefined,{month:'short'});
    const weekday=dt.toLocaleDateString(undefined,{weekday:'long'});
    return `<div class="upcoming-row"><div class="date-tile"><strong>${day}</strong><small>${esc(mon)}</small></div><div><div class="upcoming-title">${esc(e.name)}</div><div class="upcoming-sub">${esc(weekday)} · ${esc(e.date)}</div></div></div>`;
  }).join(''):'<div class="empty-state">No upcoming events. Your calendar is clear.</div>';
}
function updateGreeting(){
  const h=new Date().getHours();
  const greeting=h<12?'Good morning':h<17?'Good afternoon':'Good evening';
  const first=profileName.trim().split(/\s+/)[0];
  el('greetingTitle').innerHTML=`${esc(greeting)}${first?', '+esc(first):''} <span class="wave">✳</span>`;
  el('profileName').value=profileName;
  el('topDate').textContent=new Date().toLocaleDateString(undefined,{weekday:'short',month:'short',day:'numeric'});
  for(const node of document.querySelectorAll('.profile-button'))node.textContent=first?first[0].toUpperCase():'N';
}
function saveProfile(){profileName=el('profileName').value.trim();localStorage.setItem('nn_profile_name',profileName);updateGreeting();notice('Profile updated');}
function exportBackup(){
  if(currentNotebook!==null)saveNotes(true);
  if(currentTask!==null)saveTaskPage(true);
  const backup={version:3,exportedAt:new Date().toISOString(),notebooks,goals,tasks,events,profileName};
  const url=URL.createObjectURL(new Blob([JSON.stringify(backup,null,2)],{type:'application/json'}));
  const a=document.createElement('a');a.href=url;a.download=`nexus-notes-backup-${todayKey()}.json`;document.body.appendChild(a);a.click();a.remove();
  setTimeout(()=>URL.revokeObjectURL(url),1000);notice('Backup downloaded');
}
async function importBackupFile(event){
  const file=event.target.files?.[0];if(!file)return;
  try{
    const parsed=JSON.parse(await file.text());
    if(!Array.isArray(parsed.notebooks)||!Array.isArray(parsed.goals)||!Array.isArray(parsed.tasks)||!Array.isArray(parsed.events))throw Error('Invalid backup format');
    if(!confirm('Import this backup? It will replace your notebooks, goals, tasks and events in this browser.'))return;
    notebooks=parsed.notebooks;goals=parsed.goals;tasks=parsed.tasks;events=parsed.events;
    tasks.forEach(normalizeTask);profileName=String(parsed.profileName||'');
    localStorage.setItem('nn_profile_name',profileName);
    currentNotebook=null;currentTask=null;el('editor').classList.add('hidden');el('taskEditor').classList.add('hidden');
    saveAll();updateGreeting();notice('Backup restored');
  }catch(err){notice('Could not import: '+err.message)}finally{event.target.value='';}
}
function initialize(){
  document.documentElement.dataset.theme=localStorage.getItem('nn_theme')==='light'?'light':'dark';
  updateGreeting();renderAll();showPage('dashboard');loadVoices();
  if('speechSynthesis' in window){window.speechSynthesis.addEventListener?.('voiceschanged',loadVoices);}
  el('voiceSelect').addEventListener('change',()=>localStorage.setItem('nn_voice',availableVoices[Number(el('voiceSelect').value)]?.name||''));
  el('noteText').addEventListener('input',()=>{
    if(currentNotebook===null)return;
    notebooks[currentNotebook].pages[currentPage]=el('noteText').value;
    el('saveIndicator').textContent='Saving…';
    clearTimeout(notebookSaveTimer);
    notebookSaveTimer=setTimeout(()=>{persistAll();el('saveIndicator').textContent='✓ Saved locally';},550);
  });
  for(const id of ['taskPageTitle','taskPageText'])el(id).addEventListener('input',()=>{
    if(currentTask===null)return;
    const page=tasks[currentTask].pages[currentTaskPage];
    page.title=el('taskPageTitle').value;page.notes=el('taskPageText').value;
    clearTimeout(taskSaveTimer);taskSaveTimer=setTimeout(()=>persistAll(),600);
  });
  window.addEventListener('beforeunload',()=>{
    if(currentNotebook!==null&&notebooks[currentNotebook])notebooks[currentNotebook].pages[currentPage]=el('noteText').value;
    if(currentTask!==null&&tasks[currentTask]){
      const page=tasks[currentTask].pages[currentTaskPage];if(page){page.notes=el('taskPageText').value;page.title=el('taskPageTitle').value;}
    }
    persistAll();
  });
}
initialize();
