function createNotebook(){
  const name=el('bookName').value.trim();if(!name)return notice('Enter a notebook name first');
  notebooks.push({name,pages:Array(450).fill('')});
  el('bookName').value='';saveAll();openNotebook(notebooks.length-1);notice('Notebook created');
}
function deleteNotebook(index){
  if(!notebooks[index]||!confirm(`Delete "${notebooks[index].name}"? This cannot be undone.`))return;
  notebooks.splice(index,1);currentNotebook=null;el('editor').classList.add('hidden');saveAll();notice('Notebook deleted');
}
function openNotebook(index,page=0){
  if(!notebooks[index])return;
  showPage('notebooks');currentNotebook=index;currentPage=Math.max(0,Math.min(449,page));
  el('editor').classList.remove('hidden');el('bookTitle').textContent=notebooks[index].name;
  loadPage();el('editor').scrollIntoView({behavior:'smooth',block:'start'});
}
function loadPage(){
  if(currentNotebook===null)return;
  el('pageNum').textContent=currentPage+1;
  el('noteText').value=notebooks[currentNotebook].pages?.[currentPage]||'';
  el('saveIndicator').textContent='Your notes are saved on this device.';
}
function saveNotes(silent=false){
  if(currentNotebook===null||!notebooks[currentNotebook])return;
  notebooks[currentNotebook].pages[currentPage]=el('noteText').value;
  clearTimeout(notebookSaveTimer);persistAll();
  el('saveIndicator').textContent='✓ Saved locally';
  if(!silent){renderAll();notice('Notes saved');}
}
function nextPage(){saveNotes(true);if(currentPage<449){currentPage++;loadPage()}else notice('This notebook has 450 pages');}
function prevPage(){saveNotes(true);if(currentPage>0){currentPage--;loadPage()}}
function insertAtCursor(value){
  const box=el('noteText');
  const start=box.selectionStart,end=box.selectionEnd;
  box.value=box.value.slice(0,start)+(start>0&&box.value[start-1]!=='\n'?'\n':'')+value+box.value.slice(end);
  box.focus();box.selectionStart=box.selectionEnd=start+value.length+(start>0&&box.value[start-1]!=='\n'?1:0);
  box.dispatchEvent(new Event('input'));
}
function insertBullet(){insertAtCursor('• ')}
function insertChecklist(){insertAtCursor('☐ ')}
let availableVoices=[];
function loadVoices(){
  if(!('speechSynthesis' in window))return;
  const select=el('voiceSelect');if(!select)return;
  const oldName=select.selectedOptions[0]?.dataset.name||localStorage.getItem('nn_voice')||'';
  availableVoices=window.speechSynthesis.getVoices();
  select.replaceChildren();
  for(const [i,v] of availableVoices.entries()){
    const opt=document.createElement('option');opt.value=i;opt.textContent=`${v.name} · ${v.lang}`;opt.dataset.name=v.name;select.append(opt);
  }
  let preferred=availableVoices.findIndex(v=>v.name===oldName);
  if(preferred<0)preferred=availableVoices.findIndex(v=>/natural|samantha|google us english|aria|jenny/i.test(v.name)&&/^en/i.test(v.lang));
  if(preferred<0)preferred=availableVoices.findIndex(v=>/^en/i.test(v.lang));
  if(preferred>=0)select.value=preferred;
}
function readNotes(){
  if(!('speechSynthesis' in window))return notice('Voice reading is not available in this browser.');
  const text=el('noteText').value.trim();if(!text)return notice('Write something first to hear it read aloud');
  const utterance=new SpeechSynthesisUtterance(text);
  const voice=availableVoices[Number(el('voiceSelect').value)];if(voice)utterance.voice=voice;
  utterance.rate=Number(el('voiceSpeed').value)||1;
  window.speechSynthesis.cancel();window.speechSynthesis.speak(utterance);
}
function stopReading(){if('speechSynthesis' in window)window.speechSynthesis.cancel()}
