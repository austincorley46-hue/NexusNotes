function addGoal(){
  const title=el('goalInput').value.trim();
  if(!title)return notice('Give your goal a name');
  goals.push({title,progress:clampProgress(el('goalProgress').value),date:el('goalDate').value,priority:el('goalPriority').value});
  el('goalInput').value='';el('goalProgress').value='0';el('goalDate').value='';el('goalPriority').value='Medium';
  saveAll();notice('Goal added');
}
function updateGoalProgress(index){
  const g=goals[index];if(!g)return;
  const answer=prompt('Update progress (0 to 100):',g.progress);
  if(answer===null)return;
  if(answer.trim()===''||!Number.isFinite(Number(answer)))return notice('Enter a number from 0 to 100');
  g.progress=clampProgress(answer);saveAll();notice('Progress updated');
}
function deleteGoal(index){
  if(!goals[index]||!confirm('Delete this goal?'))return;
  goals.splice(index,1);saveAll();notice('Goal deleted');
}
function closestGoal(){
  const active=goals.filter(g=>clampProgress(g.progress)<100);
  if(!active.length)return null;
  const priority={High:0,Medium:1,Low:2};
  return [...active].sort((a,b)=>{
    const aDate=validDate(a.date)?a.date:'9999-12-31';
    const bDate=validDate(b.date)?b.date:'9999-12-31';
    return aDate.localeCompare(bDate)||(priority[a.priority]??1)-(priority[b.priority]??1);
  })[0];
}
function motivationFor(goal){
  const remaining=100-clampProgress(goal.progress);
  if(remaining<=10)return `You're almost there! The last step toward “${goal.title}” is within reach.`;
  if(clampProgress(goal.progress)>=50)return `You've already made real progress on “${goal.title}.” Keep that momentum.`;
  return `A little effort toward “${goal.title}” today can make a big difference tomorrow.`;
}
