function universalSearch(){
  const query=el('commandInput').value.toLowerCase().trim();
  const target=el('searchResults');
  const results=[];
  if(!query){
    for(const [page,label,icon] of [['notebooks','Open Notebooks','📖'],['tasks','Open Tasks','☑'],['goals','Open Goals','🎯'],['calendar','Open Calendar','📅']]){
      results.push({label,icon,kind:'Go to',action:`navigateResult('${page}')`});
    }
  }else{
    const has=s=>String(s||'').toLowerCase().includes(query);
    notebooks.forEach((b,i)=>{
      if(has(b.name))results.push({icon:'📖',label:b.name,kind:'Notebook',action:`openSearchNotebook(${i},0)`});
      (b.pages||[]).forEach((p,j)=>{if(has(p))results.push({icon:'📄',label:`${b.name} · Page ${j+1}`,kind:'Notebook page',action:`openSearchNotebook(${i},${j})`})});
    });
    goals.forEach((g)=>{if(has(g.title))results.push({icon:'🎯',label:g.title,kind:'Goal',action:"navigateResult('goals')"})});
    tasks.forEach((t,i)=>{
      if(has(t.text))results.push({icon:'☑',label:t.text,kind:'Task group',action:`openSearchTask(${i},0)`});
      (t.pages||[]).forEach((p,j)=>{
        const page=typeof p==='string'?{title:`Page ${j+1}`,notes:p,items:[]}:p;
        if(has(page.title)||has(page.notes)||(page.items||[]).some(it=>has(it.text)))results.push({icon:'📝',label:`${t.text} · ${page.title}`,kind:'Task page',action:`openSearchTask(${i},${j})`});
      });
    });
    events.forEach(e=>{if(has(e.name)||has(e.date))results.push({icon:'📅',label:`${e.name} · ${e.date}`,kind:'Event',action:"navigateResult('calendar')"})});
  }
  target.innerHTML=results.length?results.slice(0,50).map(r=>`<button class="command-result" onclick="${r.action}"><span>${r.icon}</span><span>${esc(r.label)}</span><span class="result-type">${esc(r.kind)}</span></button>`).join(''):'<div class="empty-state">Nothing found. Try a different word.</div>';
}
function navigateResult(page){closeCommand();showPage(page)}
function openSearchNotebook(index,page){closeCommand();openNotebook(index,page)}
function openSearchTask(index,page){closeCommand();openTask(index,page)}
