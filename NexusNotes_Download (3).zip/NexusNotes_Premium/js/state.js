// Keeps the same browser storage keys as the original Nexus Notes app.
function loadLocal(key, fallback){
  try {const value=JSON.parse(localStorage.getItem(key));return value===null?fallback:value;}
  catch(e){console.warn('Unable to read',key,e);return fallback;}
}
let notebooks=loadLocal('notebooks',[]);
let goals=loadLocal('goals',[]);
let tasks=loadLocal('tasks',[]);
let events=loadLocal('events',[]);
let profileName=localStorage.getItem('nn_profile_name')||'';
let currentNotebook=null,currentPage=0,currentTask=null,currentTaskPage=0;
let calendarDate=new Date();
let activePage='dashboard';
let notebookSaveTimer=null,taskSaveTimer=null;
function el(id){return document.getElementById(id)}
function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function validDate(v){return typeof v==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(v)}
function todayKey(){const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`}
function clampProgress(v){const n=Number(v);return Number.isFinite(n)?Math.max(0,Math.min(100,Math.round(n))):0}
function persistAll(){
  try{
    localStorage.setItem('notebooks',JSON.stringify(notebooks));
    localStorage.setItem('goals',JSON.stringify(goals));
    localStorage.setItem('tasks',JSON.stringify(tasks));
    localStorage.setItem('events',JSON.stringify(events));
    return true;
  }catch(e){console.error(e);notice('Storage is full or blocked. Export a backup from Settings.');return false;}
}
function saveAll(){persistAll();renderAll();}
let toastTimer;
function notice(message){
  const node=el('toast');if(!node)return;
  node.textContent=message;node.classList.remove('hidden');
  clearTimeout(toastTimer);toastTimer=setTimeout(()=>node.classList.add('hidden'),3200);
}
function normalizeTask(task){
  if(!Array.isArray(task.pages)||task.pages.length===0)task.pages=[''];
  task.pages=task.pages.map((page,i)=>typeof page==='string'
    ?{title:`Page ${i+1}`,notes:page,items:[]}
    :{title:typeof page.title==='string'?page.title:`Page ${i+1}`,notes:typeof page.notes==='string'?page.notes:'',items:Array.isArray(page.items)?page.items:[]});
}
notebooks=Array.isArray(notebooks)?notebooks:[];
goals=Array.isArray(goals)?goals:[];
tasks=Array.isArray(tasks)?tasks:[];
events=Array.isArray(events)?events:[];
tasks.forEach(normalizeTask);
