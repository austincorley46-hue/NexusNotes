const pageNames={dashboard:'Overview',notebooks:'Notebooks',tasks:'My tasks',goals:'Goals',calendar:'Calendar',ai:'AI assistant',tools:'Tools hub',settings:'Settings'};
function showPage(id){
  if(!pageNames[id])return;
  if(currentNotebook!==null && activePage==='notebooks')saveNotes(true);
  if(currentTask!==null && activePage==='tasks')saveTaskPage(true);
  activePage=id;
  document.querySelectorAll('section.view').forEach(s=>{
    const selected=s.id===id;
    s.classList.toggle('hidden',!selected);
    s.classList.toggle('active-view',selected);
    if(selected){s.style.animation='none';void s.offsetWidth;s.style.animation='';}
  });
  document.querySelectorAll('.nav-link').forEach(b=>{
    const current=b.dataset.page===id;
    b.classList.toggle('active',current);
    if(current)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current');
  });
  el('currentBreadcrumb').textContent=pageNames[id];
  el('sidebar').classList.remove('mobile-open');
  if(id==='calendar')renderCalendar();
  window.scrollTo({top:0,behavior:'instant'});
}
function quickCreate(type){
  const target=type==='task'?'tasks':type==='goal'?'goals':'notebooks';
  const input=type==='task'?'taskInput':type==='goal'?'goalInput':'bookName';
  showPage(target);setTimeout(()=>el(input).focus(),110);
}
function toggleSidebar(){el('sidebar').classList.toggle('mobile-open')}
function setTheme(theme){
  document.documentElement.dataset.theme=theme==='light'?'light':'dark';
  localStorage.setItem('nn_theme',document.documentElement.dataset.theme);
  notice(`${theme==='light'?'Light':'Dark'} mode enabled`);
}
function openCommand(){
  el('commandOverlay').classList.remove('hidden');
  el('commandInput').value='';
  universalSearch();
  setTimeout(()=>el('commandInput').focus(),10);
}
function closeCommand(){el('commandOverlay').classList.add('hidden')}
function maybeShortcut(e){
  const modifier=e.ctrlKey||e.metaKey;
  if(modifier&&e.key.toLowerCase()==='k'){e.preventDefault();el('commandOverlay').classList.contains('hidden')?openCommand():closeCommand();}
  if(modifier&&e.key.toLowerCase()==='s'){e.preventDefault();if(activePage==='notebooks')saveNotes();else if(activePage==='tasks')saveTaskPage();else persistAll();notice('Saved on this device');}
  if(modifier&&e.key.toLowerCase()==='n'){e.preventDefault();quickCreate('notebook');}
  if(e.key==='Escape'){closeCommand();el('sidebar').classList.remove('mobile-open');}
  if(e.key==='Enter'&&!el('commandOverlay').classList.contains('hidden')&&document.activeElement===el('commandInput')){
    const first=el('searchResults').querySelector('button');if(first){e.preventDefault();first.click();}
  }
}
document.addEventListener('keydown',maybeShortcut);
