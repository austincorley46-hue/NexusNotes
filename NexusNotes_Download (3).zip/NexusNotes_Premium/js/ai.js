function fakeAI(){
  const text=el('aiInput').value.trim();if(!text)return notice('Type a question first');
  el('aiOutput').textContent='Gemini is not connected yet. To answer this question securely, Nexus Notes needs an AI backend. Your question was: '+text;
  el('aiOutput').className='item';
}
