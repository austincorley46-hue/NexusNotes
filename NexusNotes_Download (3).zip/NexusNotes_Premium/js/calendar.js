function addEvent(){
  const name=el('eventInput').value.trim(),date=el('eventDate').value;
  if(!name)return notice('Enter an event name');
  if(!validDate(date))return notice('Choose a date');
  events.push({name,date});el('eventInput').value='';el('eventDate').value='';
  const [y,m]=date.split('-').map(Number);calendarDate=new Date(y,m-1,1);
  saveAll();notice('Event added');
}
function deleteEvent(index){
  if(!events[index]||!confirm('Delete this event?'))return;
  events.splice(index,1);saveAll();notice('Event deleted');
}
function prevMonth(){calendarDate=new Date(calendarDate.getFullYear(),calendarDate.getMonth()-1,1);renderCalendar()}
function nextMonth(){calendarDate=new Date(calendarDate.getFullYear(),calendarDate.getMonth()+1,1);renderCalendar()}
function todayMonth(){calendarDate=new Date();renderCalendar()}
function chooseCalendarDate(date){el('eventDate').value=date;el('eventInput').focus();el('eventInput').scrollIntoView({block:'center',behavior:'smooth'})}
function renderCalendar(){
  const grid=el('calendarGrid');if(!grid)return;
  const y=calendarDate.getFullYear(),m=calendarDate.getMonth();
  el('calendarTitle').textContent=new Date(y,m,1).toLocaleDateString(undefined,{month:'long',year:'numeric'});
  const offset=new Date(y,m,1).getDay(),length=new Date(y,m+1,0).getDate();
  const cells=[];
  for(let i=0;i<offset;i++)cells.push('<div class="day empty" aria-hidden="true"></div>');
  for(let day=1;day<=length;day++){
    const date=`${y}-${String(m+1).padStart(2,'0')}-${String(day).padStart(2,'0')}`;
    const eventsOnDay=events.filter(e=>e.date===date);
    cells.push(`<div class="day ${date===todayKey()?'today':''}" role="button" tabindex="0" title="Add an event" onclick="chooseCalendarDate('${date}')" onkeydown="if(event.key==='Enter')chooseCalendarDate('${date}')"><span class="day-number">${day}</span>${eventsOnDay.slice(0,3).map(e=>`<div class="event">${esc(e.name)}</div>`).join('')}${eventsOnDay.length>3?`<div class="event">+ ${eventsOnDay.length-3} more</div>`:''}</div>`);
  }
  grid.innerHTML=cells.join('');
}
