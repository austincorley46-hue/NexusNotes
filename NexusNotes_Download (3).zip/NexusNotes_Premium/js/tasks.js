function addTask(){
  const text=el('taskInput').value.trim();if(!text)return notice('Enter a task group name');
  tasks.push({text,done:false,pages:[{title:'Page 1',notes:'',items:[]}]});
  el('taskInput').value='';saveAll();openTask(tasks.length-1);notice('Task group created');
}
function toggleTask(index){if(!tasks[index])return;tasks[index].done=!tasks[index].done;saveAll();}
function deleteTask(index){
  if(!tasks[index]||!confirm(`Delete "${tasks[index].text}" and all its pages?`))return;
  tasks.splice(index,1);currentTask=null;el('taskEditor').classList.add('hidden');saveAll();notice('Task group deleted');
}
function openTask(index,page=0){
  if(!tasks[index])return;
  showPage('tasks');normalizeTask(tasks[index]);currentTask=index;currentTaskPage=Math.max(0,Math.min(tasks[index].pages.length-1,page));
  el('taskEditor').classList.remove('hidden');el('taskTitle').textContent=tasks[index].text;
  loadTaskPage();el('taskEditor').scrollIntoView({behavior:'smooth',block:'start'});
}
function loadTaskPage(){
  if(currentTask===null||!tasks[currentTask])return;
  const page=tasks[currentTask].pages[currentTaskPage];
  el('taskPageNum').textContent=`${currentTaskPage+1} / ${tasks[currentTask].pages.length}`;
  el('taskPageTitle').value=page.title||'';el('taskPageText').value=page.notes||'';
  renderTaskItems();
}
function saveTaskPage(silent=false){
  if(currentTask===null||!tasks[currentTask])return;
  const page=tasks[currentTask].pages[currentTaskPage];
  if(!page)return;
  page.title=el('taskPageTitle').value||`Page ${currentTaskPage+1}`;
  page.notes=el('taskPageText').value;
  clearTimeout(taskSaveTimer);persistAll();
  if(!silent){renderAll();notice('Task page saved');}
}
function addTaskPage(){
  if(currentTask===null)return;
  saveTaskPage(true);
  tasks[currentTask].pages.push({title:`Page ${tasks[currentTask].pages.length+1}`,notes:'',items:[]});
  currentTaskPage=tasks[currentTask].pages.length-1;
  saveAll();loadTaskPage();notice('Page added');
}
function nextTaskPage(){
  if(currentTask===null)return;
  saveTaskPage(true);
  if(currentTaskPage<tasks[currentTask].pages.length-1){currentTaskPage++;loadTaskPage();}else notice('Use “Add task page” to create a new page');
}
function prevTaskPage(){if(currentTask===null)return;saveTaskPage(true);if(currentTaskPage>0){currentTaskPage--;loadTaskPage();}}
function deleteTaskPage(){
  if(currentTask===null)return;
  if(tasks[currentTask].pages.length===1)return notice('Every task group needs at least one page');
  if(!confirm('Delete this task page and its checklist items?'))return;
  tasks[currentTask].pages.splice(currentTaskPage,1);
  currentTaskPage=Math.min(currentTaskPage,tasks[currentTask].pages.length-1);
  saveAll();loadTaskPage();notice('Task page deleted');
}
function addTaskItem(){
  if(currentTask===null)return;
  const input=el('taskItemInput');const text=input.value.trim();if(!text)return notice('Enter a checklist item');
  tasks[currentTask].pages[currentTaskPage].items.push({text,done:false});
  input.value='';saveAll();renderTaskItems();
}
function toggleTaskItem(index){
  if(currentTask===null)return;
  const item=tasks[currentTask].pages[currentTaskPage].items[index];if(!item)return;
  item.done=!item.done;saveAll();renderTaskItems();
}
function deleteTaskItem(index){
  if(currentTask===null)return;
  tasks[currentTask].pages[currentTaskPage].items.splice(index,1);
  saveAll();renderTaskItems();
}
function renderTaskItems(){
  const list=el('taskItemsList');if(!list||currentTask===null)return;
  const items=tasks[currentTask].pages[currentTaskPage].items;
  list.innerHTML=items.length?items.map((item,i)=>`<div class="item"><input class="task-checkbox" type="checkbox" ${item.done?'checked':''} onchange="toggleTaskItem(${i})" aria-label="Complete item"><span class="item-main ${item.done?'task-done':''}">${esc(item.text)}</span><button class="button button-danger" onclick="deleteTaskItem(${i})">Delete</button></div>`).join(''):'<div class="empty-state">No checklist items yet. Add one above.</div>';
}
