NEXUS NOTES — PROJECTS + DRAWING STUDIO UPDATE
=============================================

No Firebase setup or payment is needed. This update intentionally does not include
email/password cloud accounts. Everything stays saved in the same browser/device.

WHAT IS NEW
-----------
1. When Nexus Notes opens, choose an existing project or create a new one.
   Rename, delete, and change the accent color of projects from the chooser.
   Each project has its own notebooks, goals, task groups, events, Quick Notes,
   study tools and tutor chat history.
2. Create notebooks with custom cover colors. You can also recolor or rename
   notebooks after creating them.
3. Use the new Drawing Studio in the sidebar. Draw with a mouse, touchscreen,
   or stylus; change pen color and brush size; erase, undo, clear, save or
   download drawings; and attach saved drawings to any notebook and page.
4. In a notebook page, Ctrl+V pastes copied images; the Paste image button
   reads images from the clipboard (browser permission required). Alternatively,
   use Upload image. Pictures appear as attachments beneath the page text.
5. Settings includes larger interface size (up to 150%), high contrast,
   reduced animation, readable font, density and an accent color picker.
6. Full backup now exports all projects AND their images as a single .json file.
   Import supports new backups plus older Nexus Notes backups.

INSTALLING ON GITHUB PAGES
--------------------------
1. FIRST: Open your currently published Nexus Notes and go to
   Settings & backup -> Download backup. Save the file somewhere safe.
2. Open https://github.com/austincorley46-hue/NexusNotes/edit/main/index.html
3. Open the NEW index.html from this ZIP in Notepad, Ctrl+A then Ctrl+C.
4. In the GitHub editor, Ctrl+A then Ctrl+V, replacing the ENTIRE OLD HTML.
   Do not paste it below the old code: that produces two websites in one file.
5. Click Commit changes and confirm.
6. Open https://austincorley46-hue.github.io/NexusNotes/ and refresh once.
   You should see 'Choose your project' when you open the app.

YOUR SAVED NOTES
----------------
Your old notebooks, tasks and other local data are automatically copied into
'My first project' on the same browser and website address. The original legacy
storage keys remain untouched as a safety copy. Local storage is tied to the
same website/domain and device, not to your email. Clearing site data or using
another device may remove these locally stored projects. Download a backup
before switching browsers or clearing browser data.

Images and drawings use IndexedDB, which is local to the browser. Use the new
full-project backup to preserve them before changing devices.

NOTES
-----
Chrome/Edge on Windows should support the drawing canvas, pasted images,
local media storage, and project picker. Browser clipboard permissions vary;
if the Paste image button is blocked, click inside a notebook's text box and
press Ctrl+V or use the Upload image button.

This is a single-file standalone website (index.html). No npm, plugins,
API keys, or subscriptions required for these features.
