Nexus Notes — Projects + Drawing Studio update

1. Download and unzip this file.
2. Before updating, open your current Nexus Notes, go to Settings & backup, and download a backup of your data.
3. Open the included index.html with Notepad and copy ALL code (Ctrl+A then Ctrl+C).
4. Open https://github.com/austincorley46-hue/NexusNotes/edit/main/index.html
5. Replace all existing code (Ctrl+A then Ctrl+V). Do not append the new code.
6. Click Commit changes.
7. Open https://austincorley46-hue.github.io/NexusNotes/ and refresh.

IMPORTANT: Data is stored in your current browser until Firebase is configured.
